package peevedFowlsNewAwesomeEdition;

public interface Speediness 
{
	// the speed of the bird is multiplied by 3
	int speedMultiplier=3;
	// the speed of the bird is switched on
	public void switchSpeed();
	
}
