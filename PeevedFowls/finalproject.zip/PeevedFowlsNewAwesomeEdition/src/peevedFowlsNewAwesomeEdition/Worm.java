package peevedFowlsNewAwesomeEdition;

public class Worm extends PhysicalObject
{
	public Worm(int x,int y, int size)
	{
		xCoordinate=x;
		yCoordinate=y;
		sizeOfObject=size;
	}
}
