/**
 * 
 */
/**
 * 
 */
module PeevedFowlsNewAwesomeEdition {
	requires java.desktop;
}